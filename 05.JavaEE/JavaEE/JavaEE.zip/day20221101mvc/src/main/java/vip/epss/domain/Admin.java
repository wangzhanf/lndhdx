package vip.epss.domain;

public class Admin {
}
