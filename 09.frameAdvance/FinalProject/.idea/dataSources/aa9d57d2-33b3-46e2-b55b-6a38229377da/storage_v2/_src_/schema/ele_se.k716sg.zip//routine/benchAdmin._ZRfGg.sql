create
    definer = root@localhost procedure benchAdmin(IN rownum int)
BEGIN
    declare count integer default 1;
    while count<rownum do
            insert into admin
            (password, adminName)
            VALUES
                ('123', concat('admin',count));
            set count = count + 1;
        end while;
end;

