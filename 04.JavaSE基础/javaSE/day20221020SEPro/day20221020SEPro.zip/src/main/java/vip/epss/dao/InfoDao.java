package vip.epss.dao;

import vip.epss.pojo.Info;

import java.util.List;

public class InfoDao implements DaoImpl<Info>{
    @Override
    public Boolean deleteByPrimaryKey(Integer id) {
        return null;
    }

    @Override
    public Info selectByPrimaryKey(Integer id) {
        return null;
    }

    @Override
    public List<Info> selectAll() {
        return null;
    }

    @Override
    public Boolean insertSelective(Info obj) {
        return null;
    }

    @Override
    public Boolean updateSelective(Info obj) {
        return null;
    }
}
