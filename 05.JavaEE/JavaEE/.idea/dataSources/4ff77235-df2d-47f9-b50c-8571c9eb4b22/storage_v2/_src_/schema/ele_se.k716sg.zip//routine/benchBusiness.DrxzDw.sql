create
    definer = root@localhost procedure benchBusiness(IN rownum int)
BEGIN
    declare count integer default 1;
    while count<rownum do
            insert into business
            (password, businessName, businessAddress, businessExplain, aid)
            VALUES
                ('123', concat('商家',count), concat('地址',count), concat('介绍',count), 2);
            set count = count + 1;
    end while;
end;

