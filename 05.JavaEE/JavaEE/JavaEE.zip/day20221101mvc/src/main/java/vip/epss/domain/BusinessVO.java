package vip.epss.domain;
/*封装检索类*/
public class BusinessVO extends Business{
    private String con;

    public String getCon() {
        return con;
    }

    public void setCon(String con) {
        this.con = con;
    }
//  课间休息：   14：18

}
